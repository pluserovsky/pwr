#include "ListCell.h"

KomorkaListy::KomorkaListy() {};

KomorkaListy::~KomorkaListy() {};
